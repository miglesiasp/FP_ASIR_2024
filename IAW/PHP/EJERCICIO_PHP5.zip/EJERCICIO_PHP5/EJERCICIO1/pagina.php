<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title> Página Principal </title>
</head>
<body>
    <h1>Página Principal</h1>
    <p> Bienvenido a la página principal</p>
    <p> Para registrarte, pincha este enlace</p>
    <br>
    <a href = "registro.php"> Registro </a>
    <br>
    <p> Si ya tienes cuenta, entonces pincha este enlace</p>
    <a href = "login.php"> Login </a>
</body>
</html>
