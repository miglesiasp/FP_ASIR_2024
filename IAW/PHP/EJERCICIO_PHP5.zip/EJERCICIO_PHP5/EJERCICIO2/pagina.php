<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title> Página Principal </title>
</head>
<body>
    <h1>Página Principal</h1>
    <p> Bienvenido a la página principal</p>
    <p> Para insertar un alumno</p>
    <br>
    <a href = "insert_alumno.php"> Registro </a>
    <br>
    <p> Para matricular a un alumno</p>
    <a href = "mat_alumno.php"> Login </a>
    <br>
    <p> Para consultar los alumnos</p>
    <a href = "consulta_alum.php"> Login </a>
    <br>
    <p> Para consultar asignaturas</p>
    <a href = "consulta_asig.php"> Login </a>
    <br>
    <p> Para consultar las matrículas</p>
    <a href = "consulta_mat.php"> Login </a>
</body>
</html>